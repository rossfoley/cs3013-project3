#include <stdio.h>
#include <stdlib.h>

#define TRUE 1
#define FALSE 0
#define NINJA_COUNT 14
#define PIRATE_COUNT 18

// mutex mutex;
int[PIRATE_COUNT] piratesInRoom;
int[NINJA_COUNT] ninjasInRoom;
int ninjaAccess;
int pirateAccess;

void run_ninja(int ninjaID) {
	while(TRUE) {
		// Code to enter the costume department
		down(mutex);
		if (ninjaAccess && !ninjasInRoom[ninjaID]) {
			ninjas++;
			ninjasInRoom[ninjaID] = TRUE;
		}
		up(mutex);

		// Code to get dressed and leave
		down(mutex);
		if (ninjaAccess && ninjasInRoom[ninjaID]) {
			sleep(1); // Perform costume change
			ninjas--;
			ninjasInRoom[ninjaID] = FALSE;

			if (ninjas == 0) {
				ninjaAccess = FALSE;
				pirateAccess = TRUE;
			}
		}
		up(mutex);
	}
}

void run_pirate(int pirateID) {
	while(TRUE) {
		// Code to enter the costume department
		down(mutex);
		if (pirateAccess && !piratesInRoom[pirateID]) {
			pirates++;
			piratesInRoom[pirateID] = TRUE;
		}
		up(mutex);

		// Code to get dressed and leave
		down(mutex);
		if (pirateAccess && piratesInRoom[pirateID]) {
			sleep(1); // Perform costume change
			pirates--;
			piratesInRoom[pirateID] = FALSE;
			
			if (pirates == 0) {
				ninjaAccess = TRUE;
				pirateAccess = FALSE;
			}
		}
		up(mutex);
	}
}

int main(void) {
	// Create our threads
	return 0;
}